/* automatically generated from makefile: make version */
#define VERSION    "2.5.2 (29 April 2012)"
#define TARGET     "x86_64"
#define LASTMOD    "Sun Apr 29 21:36:06 CEST 2012"
