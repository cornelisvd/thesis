setGeneric(
    name = "getAttributes",
    def = function(object, ...) {
        standardGeneric("getAttributes")
    }
)
