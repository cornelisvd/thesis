setGeneric(
    name = "getNumberOfStrata",
    def = function(object, ...) {
        standardGeneric("getNumberOfStrata")
    }
)
