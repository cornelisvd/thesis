setClass(
    Class = "SamplingPatternRandomSamplingUnits",
    contains = "SamplingPatternRandom"
)
