setGeneric(
    name = "stratify",
    def = function(object, ...) {
        standardGeneric("stratify")
    }
)
