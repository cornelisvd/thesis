setGeneric(
    name = "estimate",
    def = function(statistic, stratification, samplingPattern, data, ...) {
        standardGeneric("estimate")
    }
)
