setClass(
    Class = "StandardError",
    prototype = prototype(
        description = "standard error"
    ),
    contains = "SamplingVariance"
)
