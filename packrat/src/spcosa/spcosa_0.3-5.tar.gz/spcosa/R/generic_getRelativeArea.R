setGeneric(
    name = "getRelativeArea",
    def = function(object, ...) {
        standardGeneric("getRelativeArea")
    }
)
