setClass(
    Class = "SamplingVariance",
    prototype = prototype(
        description = "sampling variance"
    ),
    contains = "Statistic"
)
