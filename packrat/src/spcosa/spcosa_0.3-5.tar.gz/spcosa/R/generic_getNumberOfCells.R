setGeneric(
    name = "getNumberOfCells",
    def = function(object, ...) {
        standardGeneric("getNumberOfCells")
    }
)
