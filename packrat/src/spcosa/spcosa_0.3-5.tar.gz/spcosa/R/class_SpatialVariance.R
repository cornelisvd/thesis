setClass(
    Class = "SpatialVariance",
    prototype = prototype(
        description = "spatial variance"
    ),
    contains = "Statistic"
)
