setClass(
    Class = "CompactStratificationEqualArea",
    contains = "CompactStratification"
)
