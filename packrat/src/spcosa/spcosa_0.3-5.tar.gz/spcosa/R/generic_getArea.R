setGeneric(
    name = "getArea",
    def = function(object, ...) {
        standardGeneric("getArea")
    }
)
