setClass(
    Class = "SamplingPatternCentroids",
    contains = "SamplingPatternPurposive"
)
