setClass(
    Class = "SpatialCumulativeDistributionFunction",
    prototype = prototype(
        description = "spatial cumulative distribution function (SCDF)"
    ),
    contains = "Statistic"
)
