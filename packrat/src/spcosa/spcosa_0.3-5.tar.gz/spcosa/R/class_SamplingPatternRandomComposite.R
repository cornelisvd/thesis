setClass(
    Class = "SamplingPatternRandomComposite",
    representation = representation(
        composite = "integer"
    ),
    contains = "SamplingPatternRandom"
)
